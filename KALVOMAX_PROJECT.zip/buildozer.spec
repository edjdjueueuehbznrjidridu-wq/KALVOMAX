[app]
title = KALVO Market Lab
package.name = apexterminal
package.domain = ai.apex.terminal
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,json,txt
source.exclude_dirs = tests,bin,.git,__pycache__,.buildozer
version = 6.1.0
requirements = python3,kivy==2.3.0,certifi
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 36
android.minapi = 24
android.ndk = 28c
android.sdk = 36
android.accept_sdk_license = True
android.archs = arm64-v8a
android.allow_backup = False
android.logcat_filters = *:S python:D
p4a.branch = master
android.release_artifact = apk
android.debug_artifact = apk

[buildozer]
log_level = 2
warn_on_root = 0
bin_dir = ./bin
