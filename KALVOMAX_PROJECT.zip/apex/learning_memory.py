# -*- coding: utf-8 -*-
"""Day-by-day adaptive memory over demo trades (local, transparent).

Stores lightweight weights in settings JSON so the assistant and auto-trader
gradually bias risk and symbol preferences from the user's own paper results.
This is not a black-box neural net — weights are inspectable.
"""
from __future__ import annotations

import json
import time
from typing import Any, Dict

from . import storage
from . import learning as base


def _load() -> Dict[str, Any]:
    raw = storage.get_setting("learning_memory_v1", "")
    if not raw:
        return {"updated": 0, "symbol_bias": {}, "side_bias": {}, "sessions": 0, "notes": []}
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            return {"updated": 0, "symbol_bias": {}, "side_bias": {}, "sessions": 0, "notes": []}
        data.setdefault("symbol_bias", {})
        data.setdefault("side_bias", {})
        data.setdefault("sessions", 0)
        data.setdefault("notes", [])
        return data
    except Exception:
        return {"updated": 0, "symbol_bias": {}, "side_bias": {}, "sessions": 0, "notes": []}


def _save(data: Dict[str, Any]) -> None:
    data["updated"] = time.time()
    storage.set_setting("learning_memory_v1", json.dumps(data, ensure_ascii=False))


def refresh_from_history() -> Dict[str, Any]:
    """Recompute soft biases from closed paper trades."""
    hist = base.analyze_history(400)
    mem = _load()
    symbol_bias = dict(mem.get("symbol_bias") or {})
    side_bias = dict(mem.get("side_bias") or {})

    by_symbol = hist.get("by_symbol") or {}
    for sym, stats in by_symbol.items():
        try:
            n = int(stats.get("trades") or 0)
            wr = float(stats.get("win_rate") or 0)
            avg = float(stats.get("avg_pnl") or 0)
        except Exception:
            continue
        if n < 3:
            continue
        # map to [-1, 1]
        score = max(-1.0, min(1.0, (wr - 50.0) / 50.0 * 0.6 + (1 if avg > 0 else -1) * 0.2))
        prev = float(symbol_bias.get(sym, 0) or 0)
        symbol_bias[sym] = round(prev * 0.7 + score * 0.3, 4)

    by_side = hist.get("by_side") or {}
    for side, stats in by_side.items():
        try:
            n = int(stats.get("trades") or 0)
            wr = float(stats.get("win_rate") or 0)
        except Exception:
            continue
        if n < 5:
            continue
        score = max(-1.0, min(1.0, (wr - 50.0) / 50.0))
        prev = float(side_bias.get(side, 0) or 0)
        side_bias[str(side).lower()] = round(prev * 0.7 + score * 0.3, 4)

    mem["symbol_bias"] = symbol_bias
    mem["side_bias"] = side_bias
    mem["regime_bias"] = _regime_stats()
    try:
        newest = storage.list_trades(1)
        mem["last_trade_id"] = int(newest[0]["id"]) if newest else 0
    except Exception:
        pass
    mem["sessions"] = int(mem.get("sessions") or 0) + 1
    mem["last_hist"] = {
        "trades": hist.get("sample") or 0,
        "win_rate": hist.get("win_rate"),
        "profit_factor": hist.get("profit_factor"),
    }
    _save(mem)
    return mem


def _regime_stats() -> Dict[str, Any]:
    """Per-market-regime learning from closed *auto* trades (regime stored in the note)."""
    import re
    groups: Dict[str, list] = {}
    for t in storage.list_trades(500):
        if t.get("trade_source") != "auto":
            continue
        m = re.search(r"regime=([a-z]+)", t.get("position_note") or "")
        if not m:
            continue
        try:
            groups.setdefault(m.group(1), []).append(float(t.get("pnl") or 0))
        except (TypeError, ValueError):
            continue
    out: Dict[str, Any] = {}
    for regime, vals in groups.items():
        n = len(vals)
        if n < 6:
            continue
        wr = sum(1 for v in vals if v > 1e-9) / n * 100.0
        avg = sum(vals) / n
        bias = max(-1.0, min(1.0, (wr - 50.0) / 50.0 * 0.6 + (1 if avg > 0 else -1) * 0.4))
        out[regime] = {"n": n, "win_rate": round(wr, 1), "avg_pnl": round(avg, 4),
                       "bias": round(bias, 3)}
    return out


def regime_bias(regime: str) -> Dict[str, Any]:
    """Learned bias for one market regime: {'n': samples, 'bias': -1..1}."""
    return dict((_load().get("regime_bias") or {}).get(regime) or {"n": 0, "bias": 0.0})


def refresh_if_new_trades() -> Dict[str, Any]:
    """Automatic retraining: recompute only when a new closed trade exists."""
    mem = _load()
    try:
        newest = storage.list_trades(1)
        latest = int(newest[0]["id"]) if newest else 0
    except Exception:
        return mem
    if latest != int(mem.get("last_trade_id") or 0):
        return refresh_from_history()
    return mem


def risk_scale() -> float:
    """Return a 0.7..1.0 risk multiplier. Reduce-only: memory never enlarges risk."""
    mem = _load()
    hist = mem.get("last_hist") or {}
    try:
        if int(hist.get("trades") or 0) < 20:
            return 1.0  # insufficient sample -> base policy
        wr = float(hist.get("win_rate") if hist.get("win_rate") is not None else 50)
    except Exception:
        return 1.0
    if wr >= 52:
        return 1.0
    if wr >= 45:
        return 0.85
    return 0.7


def symbol_priority_boost(symbol: str) -> float:
    mem = _load()
    return float((mem.get("symbol_bias") or {}).get(symbol, 0) or 0)


def format_memory_fa() -> str:
    mem = refresh_if_new_trades()
    lines = ["حافظهٔ تطبیقی KALVO (فقط معاملات دموی خودت):"]
    lines.append(f"تعداد به‌روزرسانی: {mem.get('sessions', 0)}")
    sb = mem.get("symbol_bias") or {}
    if sb:
        top = sorted(sb.items(), key=lambda x: x[1], reverse=True)[:8]
        lines.append("تمایل نمادها (مثبت=نتیجهٔ بهتر در تاریخچه):")
        for s, v in top:
            lines.append(f"  · {s}: {v:+.2f}")
    sides = mem.get("side_bias") or {}
    if sides:
        lines.append("تمایل جهت: " + ", ".join(f"{k}={v:+.2f}" for k, v in sides.items()))
    rb = mem.get("regime_bias") or {}
    if rb:
        lines.append("یادگیری به تفکیک رژیم بازار: " + ", ".join(
            f"{k}: n={v['n']} bias={v['bias']:+.2f}" for k, v in rb.items()))
    lines.append(f"ضریب ریسک (فقط کاهشی): {risk_scale():.2f}")
    lines.append("این وزن‌ها تضمین سود نیستند؛ فقط خلاصهٔ نتایج مجازی خودت هستند.")
    return "\n".join(lines)


def evaluate_setup(features: dict) -> dict:
    """Soft score for a candidate using symbol bias and risk_scale (no DB required)."""
    try:
        sym = str((features or {}).get("symbol") or "")
        boost = symbol_priority_boost(sym) if sym else 0.0
        scale = risk_scale()
    except Exception:
        boost, scale = 0.0, 1.0
    score = max(0.0, min(1.0, 0.5 + boost * 0.25 + (scale - 1.0) * 0.2))
    return {"score": score, "boost": boost, "risk_scale": scale, "accept": score >= 0.45}
