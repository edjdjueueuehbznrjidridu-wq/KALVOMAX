# -*- coding: utf-8 -*-
"""Opt-in long-horizon SPOT paper assistant.

This module operates only on KALVO's virtual spot wallet. It reads public market
candles and never sends orders or credentials to an exchange.
"""
from __future__ import annotations
import time
from typing import Any, Dict
from . import analysis_engine as analysis
from . import market_apis as market
from . import storage as store

COOLDOWN_SECONDS = 4 * 60 * 60
MAX_ALLOC_PCT = 10.0
MAX_ORDER_USDT = 150.0
MIN_CONFLUENCE = 75
MAX_VOLATILITY_RATIO = 2.5


def scan_once(symbol: str, now: float | None = None) -> Dict[str, Any]:
    stamp = float(now if now is not None else time.time())
    ticker = market.get_ticker(symbol)
    price = float((ticker or {}).get('price') or 0)
    ticker_ts = float((ticker or {}).get('ts') or 0)
    if price <= 0 or ticker_ts <= 0 or stamp - ticker_ts > 45:
        return {'action': 'HOLD', 'reason': 'قیمت تازه دریافت نشد؛ هیچ معامله‌ای انجام نشد.'}

    frames: Dict[str, Dict[str, Any]] = {}
    for tf in ('4hour', '1day'):
        raw = market.fetch_candles(symbol, tf)
        closed = analysis.completed_candles(raw, tf, stamp)
        seconds = analysis.TIMEFRAME_SECONDS[tf]
        if not closed or stamp - float(closed[-1].get('time') or 0) > seconds * 2.2:
            return {'action': 'HOLD', 'reason': f'دادهٔ بسته‌شدهٔ {tf} کافی یا تازه نیست.'}
        result = analysis.analyze_candles(closed)
        if not result.get('ready'):
            return {'action': 'HOLD', 'reason': result.get('reason') or f'تحلیل {tf} کامل نیست.'}
        frames[tf] = result

    # Require agreement between both horizons. This is only a transparent
    # training rule, not a prediction or a claim of positive expectancy.
    strong = all(int(frames[tf].get('confluence_score') or 0) >= MIN_CONFLUENCE
                 for tf in frames)
    volatility_ok = all(float(frames[tf].get('volatility_ratio') or 1.0) <= MAX_VOLATILITY_RATIO
                         for tf in frames)
    long_ok = strong and volatility_ok and all(
        frames[tf].get('signal') == 'LONG_BIAS' for tf in frames)
    short_ok = strong and volatility_ok and all(
        frames[tf].get('signal') == 'SHORT_BIAS' for tf in frames)
    base = market.normalize_symbol(symbol)[0]
    balances = {r['asset']: r for r in store.get_spot_balances()}
    holding = float((balances.get(base) or {}).get('free') or 0)
    usdt = float((balances.get('USDT') or {}).get('free') or 0)
    key = f'spot_auto_last_{base}'
    last = float(store.get_setting(key, '0') or 0)
    if stamp - last < COOLDOWN_SECONDS:
        return {'action': 'HOLD', 'reason': 'فاصلهٔ ایمنی چهار ساعته هنوز تمام نشده.',
                'price': price, 'holding': holding, 'usdt': usdt}

    if long_ok and holding <= 1e-12:
        amount = min(usdt * MAX_ALLOC_PCT / 100.0, MAX_ORDER_USDT)
        if amount < 10:
            return {'action': 'HOLD', 'reason': 'موجودی مجازی USDT برای سفارش آزمایشی کافی نیست.',
                    'price': price, 'holding': holding, 'usdt': usdt}
        trade = store.spot_market_order(base, 'BUY', amount, price,
                                        note='ورود دستیار بلندمدت اسپات دمو')
        store.set_setting(key, str(int(stamp)))
        return {'action': 'BUY', 'reason': 'هر دو بازهٔ ۴ ساعته و روزانه هم‌جهت‌اند، امتیاز هر دو از آستانه گذشته و نوسان افراطی شناسایی نشده است.',
                'price': price, 'trade': trade, 'frames': frames}

    if short_ok and holding > 1e-12:
        trade = store.spot_market_order(base, 'SELL', holding, price,
                                        note='خروج دستیار بلندمدت اسپات دمو')
        store.set_setting(key, str(int(stamp)))
        return {'action': 'SELL', 'reason': 'هر دو بازهٔ ۴ ساعته و روزانه هم‌جهت منفی‌اند و دارایی مجازی بسته شد.',
                'price': price, 'trade': trade, 'frames': frames}

    return {'action': 'HOLD', 'reason': 'هم‌جهتی و قدرت سیگنال کافی نیست یا نوسان از سقف مجاز بالاتر است.',
            'price': price, 'holding': holding, 'usdt': usdt, 'frames': frames}
