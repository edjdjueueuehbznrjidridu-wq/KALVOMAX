# -*- coding: utf-8 -*-
"""Public market-data adapters for KALVO.

Read-only endpoints only. Failed requests are never presented as fresh data;
failed/empty values are not cached, so the next refresh can recover promptly.
"""
from __future__ import annotations

import json
import math
import re
import ssl
import threading
import time
import urllib.parse
import urllib.request

try:
    import certifi
except Exception:
    certifi = None
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

UA = "KALVO/4.1 (Android; read-only market data)"
_lock = threading.RLock()
_cache: Dict[str, Tuple[float, Any]] = {}
TTL_PX = 2.0
TTL_SLOW = 15.0
MAX_CANDLES = 500


def _get(url: str, timeout: int = 8) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
    context = ssl.create_default_context(cafile=certifi.where()) if certifi else ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=max(2, min(30, int(timeout))), context=context) as response:
        raw = response.read(4 * 1024 * 1024 + 1)
        if len(raw) > 4 * 1024 * 1024:
            raise ValueError("پاسخ سرویس بازار بیش از حد بزرگ است")
        return raw


def _json(url: str, timeout: int = 8) -> Any:
    data = json.loads(_get(url, timeout).decode("utf-8"))
    if not isinstance(data, (dict, list)):
        raise ValueError("ساختار پاسخ سرویس بازار نامعتبر است")
    return data


def _cached(key: str, ttl: float, fn):
    now = time.monotonic()
    with _lock:
        hit = _cache.get(key)
        if hit and now - hit[0] < ttl:
            return hit[1]
    value = fn()
    # Do not cache failed, empty, or structurally unusable market responses.
    cacheable = value is not None and value != {} and value != []
    if isinstance(value, dict):
        if value.get("error"):
            cacheable = False
        if "price" in value and _positive(value.get("price")) is None:
            cacheable = False
        if "bids" in value or "asks" in value:
            cacheable = cacheable and bool(value.get("bids") or value.get("asks"))
    if cacheable:
        with _lock:
            _cache[key] = (time.monotonic(), value)
    return value


def clear_cache() -> None:
    with _lock:
        _cache.clear()


def normalize_symbol(symbol: str) -> Tuple[str, str, str]:
    """Return base, KuCoin spot pair, and Binance spot pair."""
    s = (symbol or "BTC").upper().strip().replace("_", "-").replace("/", "-")
    s = re.sub(r"\s+", "", s)
    if s.endswith("-USDT"):
        base = s[:-5]
    elif s.endswith("USDT"):
        base = s[:-4]
    elif "-" in s:
        raise ValueError("در حال حاضر فقط جفت‌های USDT پشتیبانی می‌شوند")
    else:
        base = s
    if not re.fullmatch(r"[A-Z0-9]{2,20}", base):
        raise ValueError("نماد بازار نامعتبر است")
    return base, f"{base}-USDT", f"{base}USDT"


def _finite_number(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def _positive(value: Any) -> Optional[float]:
    n = _finite_number(value)
    return n if n is not None and n > 0 else None


def _binance_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.binance.com/api/v3/ticker/price?symbol={base}USDT", 6)
        return _positive(j.get("price"))
    except Exception:
        return None


def _binance_24h(base: str) -> Optional[Dict[str, float]]:
    try:
        j = _json(f"https://api.binance.com/api/v3/ticker/24hr?symbol={base}USDT", 8)
        price = _positive(j.get("lastPrice"))
        if price is None:
            return None
        return {
            "price": price,
            "change_pct": _finite_number(j.get("priceChangePercent"), 0.0),
            "high": _positive(j.get("highPrice")),
            "low": _positive(j.get("lowPrice")),
            "volume": _positive(j.get("quoteVolume")) or 0.0,
            "bid": _positive(j.get("bidPrice")),
            "ask": _positive(j.get("askPrice")),
        }
    except Exception:
        return None


def _kucoin_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.kucoin.com/api/v1/market/orderbook/level1?symbol={base}-USDT", 6)
        if j.get("code") not in (None, "200000"):
            return None
        return _positive((j.get("data") or {}).get("price"))
    except Exception:
        return None


def _kucoin_stats(base: str) -> Optional[Dict[str, Any]]:
    try:
        j = _json(f"https://api.kucoin.com/api/v1/market/stats?symbol={base}-USDT", 8)
        if j.get("code") not in (None, "200000"):
            return None
        d = j.get("data") or {}
        last = _positive(d.get("last"))
        if last is None:
            return None
        return {"price": last, "change_pct": _finite_number(d.get("changeRate"), 0.0) * 100,
                "high": _positive(d.get("high")), "low": _positive(d.get("low")),
                "volume": _positive(d.get("volValue")) or 0.0,
                "bid": _positive(d.get("buy")), "ask": _positive(d.get("sell"))}
    except Exception:
        return None


def _bybit_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://api.bybit.com/v5/market/tickers?category=spot&symbol={base}USDT", 6)
        if int(j.get("retCode", -1)) != 0:
            return None
        rows = (j.get("result") or {}).get("list") or []
        return _positive(rows[0].get("lastPrice")) if rows else None
    except Exception:
        return None


def _okx_price(base: str) -> Optional[float]:
    try:
        j = _json(f"https://www.okx.com/api/v5/market/ticker?instId={base}-USDT", 6)
        if str(j.get("code", "0")) != "0":
            return None
        rows = j.get("data") or []
        return _positive(rows[0].get("last")) if rows else None
    except Exception:
        return None


def _gate_price(base: str) -> Optional[float]:
    try:
        pair = urllib.parse.quote(f"{base}_USDT", safe="")
        j = _json(f"https://api.gateio.ws/api/v4/spot/tickers?currency_pair={pair}", 6)
        if isinstance(j, list) and j:
            return _positive(j[0].get("last"))
    except Exception:
        return None
    return None


def get_ticker(symbol: str) -> Dict[str, Any]:
    base, kucoin_pair, binance_pair = normalize_symbol(symbol)

    def _do():
        now = int(time.time())
        out: Dict[str, Any] = {"base": base, "symbol": kucoin_pair, "binance": binance_pair,
                               "price": None, "change_pct": None, "high": None, "low": None,
                               "volume": None, "bid": None, "ask": None, "source": None,
                               "ts": now, "stale": False}
        providers = (("binance", _binance_24h), ("kucoin", _kucoin_stats))
        for source, fn in providers:
            data = fn(base)
            if data and _positive(data.get("price")):
                out.update(data)
                out["source"] = source
                out["ts"] = int(time.time())
                return out
        for source, fn in (("bybit", _bybit_price), ("okx", _okx_price),
                           ("gate", _gate_price), ("binance", _binance_price),
                           ("kucoin", _kucoin_price)):
            price = fn(base)
            if price:
                out.update({"price": price, "source": source, "ts": int(time.time())})
                return out
        out["error"] = "هیچ منبعی قیمت تازه و معتبر برنگرداند"
        return out

    return _cached(f"ticker:{base}", TTL_PX, _do)


def get_live_price(symbol: str) -> Optional[float]:
    result = get_ticker(symbol)
    return _positive(result.get("price")) if result else None


def get_prices_batch(symbols: List[str]) -> Dict[str, float]:
    bases = []
    for symbol in symbols:
        try:
            base, _, _ = normalize_symbol(symbol)
        except ValueError:
            continue
        if base not in bases:
            bases.append(base)
    result: Dict[str, float] = {}
    if not bases:
        return result
    with ThreadPoolExecutor(max_workers=min(6, len(bases))) as pool:
        jobs = {pool.submit(get_live_price, base): base for base in bases[:30]}
        for future in as_completed(jobs):
            base = jobs[future]
            try:
                price = future.result()
                if price:
                    result[base] = price
                    result[f"{base}-USDT"] = price
                    result[f"{base}USDT"] = price
            except Exception:
                continue
    return result


KC_TF = {"1min": "1min", "3min": "3min", "5min": "5min", "15min": "15min",
         "30min": "30min", "1hour": "1hour", "2hour": "2hour", "4hour": "4hour",
         "1day": "1day", "1week": "1week", "1m": "1min", "3m": "3min",
         "5m": "5min", "15m": "15min", "30m": "30min", "1h": "1hour",
         "2h": "2hour", "4h": "4hour", "1d": "1day", "1w": "1week"}


def fetch_candles(symbol: str, tf: str = "1hour", start: int = 0, end: int = 0) -> List[Dict[str, float]]:
    """Read OHLCV from KuCoin, with Binance public klines as a fallback."""
    base, pair, binance_pair = normalize_symbol(symbol)
    interval = KC_TF.get(str(tf).lower(), "1hour")
    end = int(end or time.time())
    seconds = {"1min": 60, "3min": 180, "5min": 300, "15min": 900, "30min": 1800,
               "1hour": 3600, "2hour": 7200, "4hour": 14400, "1day": 86400,
               "1week": 604800}[interval]
    start = int(start or (end - MAX_CANDLES * seconds))
    if start >= end:
        raise ValueError("بازه زمانی کندل نامعتبر است")
    key = f"candles:{base}:{interval}:{start}:{end // max(60, seconds)}"

    def _valid(rows):
        output = []
        for row in rows:
            try:
                t = int(row["time"])
                opn, close = float(row["open"]), float(row["close"])
                high, low = float(row["high"]), float(row["low"])
                volume = float(row.get("volume") or 0)
                nums = (opn, close, high, low, volume)
                if not all(math.isfinite(x) for x in nums) or min(opn, close, high, low) <= 0:
                    continue
                if high < max(opn, close, low) or low > min(opn, close, high):
                    continue
                output.append({"time": t, "open": opn, "close": close, "high": high,
                               "low": low, "volume": max(0.0, volume)})
            except (ValueError, TypeError, KeyError, IndexError):
                continue
        dedup = {row["time"]: row for row in sorted(output, key=lambda x: x["time"])}
        return list(dedup.values())[-MAX_CANDLES:]

    def _kucoin():
        query = urllib.parse.urlencode({"type": interval, "symbol": pair,
                                        "startAt": start, "endAt": end})
        j = _json(f"https://api.kucoin.com/api/v1/market/candles?{query}", 15)
        if j.get("code") not in (None, "200000"):
            return []
        rows = []
        for r in j.get("data") or []:
            if len(r) >= 6:
                rows.append({"time": int(r[0]), "open": r[1], "close": r[2],
                             "high": r[3], "low": r[4], "volume": r[5]})
        return _valid(rows)

    def _binance():
        bn_tf = {"1min": "1m", "3min": "3m", "5min": "5m", "15min": "15m",
                 "30min": "30m", "1hour": "1h", "2hour": "2h", "4hour": "4h",
                 "1day": "1d", "1week": "1w"}[interval]
        query = urllib.parse.urlencode({"symbol": binance_pair, "interval": bn_tf,
                                        "startTime": start * 1000, "endTime": end * 1000,
                                        "limit": MAX_CANDLES})
        payload = _json(f"https://api.binance.com/api/v3/klines?{query}", 15)
        if not isinstance(payload, list):
            return []
        rows = []
        for row in payload:
            if len(row) >= 6:
                rows.append({"time": int(row[0]) // 1000, "open": row[1],
                             "high": row[2], "low": row[3], "close": row[4],
                             "volume": row[5]})
        return _valid(rows)

    def _do():
        try:
            rows = _kucoin()
            if rows:
                return rows
        except Exception:
            pass
        try:
            return _binance()
        except Exception:
            return []

    return _cached(key, TTL_SLOW, _do) or []


def fetch_orderbook(symbol: str, depth: int = 20) -> Dict[str, Any]:
    """Best-effort public order book with a second public data source."""
    base, pair, binance_pair = normalize_symbol(symbol)
    depth = 100 if depth == 100 else 20

    def _clean(bids, asks, source):
        clean_bids, clean_asks = [], []
        for dest, rows in ((clean_bids, bids or []), (clean_asks, asks or [])):
            for row in rows[:depth]:
                try:
                    px, qty = float(row[0]), float(row[1])
                    if px > 0 and qty > 0 and math.isfinite(px * qty):
                        dest.append([px, qty])
                except Exception:
                    continue
        clean_bids.sort(key=lambda x: x[0], reverse=True)
        clean_asks.sort(key=lambda x: x[0])
        if not clean_bids or not clean_asks:
            return None
        return {"bids": clean_bids, "asks": clean_asks,
                "ts": int(time.time()), "source": source}

    def _do():
        try:
            j = _json(f"https://api.kucoin.com/api/v1/market/orderbook/level2_20?symbol={pair}", 8)
            if j.get("code") in (None, "200000"):
                d = j.get("data") or {}
                result = _clean(d.get("bids"), d.get("asks"), "kucoin")
                if result:
                    return result
        except Exception:
            pass
        try:
            j = _json(f"https://api.binance.com/api/v3/depth?symbol={binance_pair}&limit={depth}", 8)
            return _clean(j.get("bids"), j.get("asks"), "binance")
        except Exception:
            return None

    return _cached(f"orderbook:{base}:{depth}", TTL_PX, _do) or {
        "bids": [], "asks": [], "ts": None, "source": None}

def funding_rate(base: str) -> Optional[float]:
    base, _, _ = normalize_symbol(base)
    contract = "XBTUSDTM" if base == "BTC" else f"{base}USDTM"

    def _do():
        try:
            j = _json(f"https://api-futures.kucoin.com/api/v1/funding-rate/{contract}/current", 8)
            if j.get("code") not in (None, "200000"):
                return None
            d = j.get("data") or {}
            value = d.get("value")
            if value is None:
                value = d.get("fundingRate")
            return float(value) if value is not None and math.isfinite(float(value)) else None
        except Exception:
            return None

    return _cached(f"funding:{base}", TTL_SLOW, _do)


def open_interest(base: str) -> Optional[float]:
    base, _, _ = normalize_symbol(base)
    contract = "XBTUSDTM" if base == "BTC" else f"{base}USDTM"

    def _do():
        try:
            j = _json(f"https://api-futures.kucoin.com/api/v1/contracts/{contract}", 8)
            if j.get("code") not in (None, "200000"):
                return None
            d = j.get("data") or {}
            value = d.get("openInterest") or d.get("openInterestQty")
            n = float(value) if value is not None else 0.0
            return n if n > 0 and math.isfinite(n) else None
        except Exception:
            return None

    return _cached(f"open_interest:{base}", TTL_SLOW, _do)


def health_check() -> List[Dict[str, Any]]:
    tests = [
        ("Binance", "https://api.binance.com/api/v3/ping"),
        ("KuCoin", "https://api.kucoin.com/api/v1/status"),
        ("Bybit", "https://api.bybit.com/v5/market/time"),
        ("OKX", "https://www.okx.com/api/v5/public/time"),
        ("Gate", "https://api.gateio.ws/api/v4/spot/currency_pairs?limit=1"),
    ]
    out = []
    for name, url in tests:
        start = time.monotonic()
        ok, err = False, ""
        try:
            payload = _json(url, 6)
            if isinstance(payload, dict):
                if "retCode" in payload and int(payload.get("retCode", -1)) != 0:
                    raise ValueError(str(payload.get("retMsg") or "خطای API"))
                if "code" in payload and str(payload.get("code")) not in ("0", "200000"):
                    raise ValueError(str(payload.get("msg") or "خطای API"))
            ok = True
        except Exception as exc:
            err = str(exc)[:100]
        out.append({"name": name, "ok": ok, "ms": int((time.monotonic() - start) * 1000), "error": err})
    return out


def rich_snapshot(symbol: str) -> Dict[str, Any]:
    base, pair, binance_pair = normalize_symbol(symbol)
    ticker = get_ticker(base)
    # These independent read-only requests can run in parallel to avoid blocking the AI screen.
    with ThreadPoolExecutor(max_workers=3) as pool:
        f_book = pool.submit(fetch_orderbook, base)
        f_funding = pool.submit(funding_rate, base)
        f_oi = pool.submit(open_interest, base)
        book = f_book.result()
        funding = f_funding.result()
        oi = f_oi.result()
    bids, asks = book.get("bids") or [], book.get("asks") or []
    spread = depth_imbalance = None
    bid_depth = ask_depth = None
    try:
        if bids and asks and float(bids[0][0]) > 0:
            candidate = (float(asks[0][0]) - float(bids[0][0])) / float(bids[0][0]) * 100.0
            spread = candidate if math.isfinite(candidate) and candidate >= 0 else None
        bid_depth = sum(float(px) * float(qty) for px, qty in bids[:20])
        ask_depth = sum(float(px) * float(qty) for px, qty in asks[:20])
        total_depth = bid_depth + ask_depth
        if total_depth > 0 and math.isfinite(total_depth):
            depth_imbalance = (bid_depth - ask_depth) / total_depth * 100.0
    except (TypeError, ValueError, OverflowError):
        pass
    return {**ticker, "symbol": pair, "binance": binance_pair,
            "funding": funding, "open_interest": oi, "spread_pct": spread,
            "depth_imbalance_pct": depth_imbalance,
            "bid_depth_usdt": bid_depth if bids and asks else None,
            "ask_depth_usdt": ask_depth if bids and asks else None,
            "bid": float(bids[0][0]) if bids else ticker.get("bid"),
            "ask": float(asks[0][0]) if asks else ticker.get("ask"),
            "orderbook_ts": book.get("ts"), "orderbook_source": book.get("source")}


POPULAR = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "LINK", "AVAX", "DOT", "MATIC",
           "LTC", "BCH", "ATOM", "NEAR", "APT", "SUI", "ARB", "OP", "INJ", "TIA",
           "PEPE", "WIF", "BNB", "TON", "TRX", "SHIB", "FIL", "UNI", "AAVE", "FET"]
